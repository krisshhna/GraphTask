const { allListing, recLineChart, recRadar, recScatter }    =   require("./listing.controller");
const router            =   require('express').Router();


router.get('/allListing',       allListing);

module.exports  =   router;