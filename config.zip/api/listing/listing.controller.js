const catchAsync = require('../../utils/catchAsync');
const { allDoughnut, allLineChart, allRadar, allScatter }   =   require('./listing.services');

module.exports  =   {
    allListing:catchAsync( async(req, res, next)=>{
        const doughnut      =   await allDoughnut();
        const lineChart     =   await allLineChart();
        const radar         =   await allRadar();
        const scatter       =   await allScatter();

        for(let rec of lineChart){
            rec.data = JSON.parse(rec.data);
            rec.labels = JSON.parse(rec.labels);
        }
       
        const result        =   {
            'doughnut':     doughnut,
            'lineChart':    lineChart,
            'radar':        radar,
            'scatter':      scatter,
        };

        return res.status(200).json({
            status:     1,
            result:     result
        })
    }),
}