const knex  =   require('../../config/database');

module.exports  =   {
    allDoughnut:(data)=>{
        return new Promise((resolve, reject)=>{
            const rec   =   knex('doughnut').select('label','data',);
            resolve(rec);
        });
    }, 
    allLineChart:(data)=>{
        return new Promise((resolve, reject)=>{
            const rec   =   knex('line_chart').select('id','labels','data');
            resolve(rec);
        })
    }, 
    allRadar:(data)=>{
        return new Promise((resolve, reject)=>{
            const rec   =   knex('radar').select('id','label','data','names');
            resolve(rec);
        })
    }, 
    allScatter:(data)=>{
        return new Promise((resolve, reject)=>{
            const rec   =   knex('scatter').select('xAxis as x','yAxis as y');
            resolve(rec);
        })
    }
}