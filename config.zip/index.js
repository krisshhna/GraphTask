require('dotenv').config();
const express       =   require('express');
const app           =   express();
const listingRouter =   require('./api/listing/listing.router');
const cors          =   require('cors');

app.get('/api', (req, res)=>{
    res.json({
        success:    1,
        message:    'This is the rest api working',
    })
});

app.use(cors({
    origin:'*'
}))

app.use('/api/listing',     listingRouter);

app.listen(process.env.APP_PORT, ()=>{
    console.log('Server is up and running', process.env.APP_PORT);
})