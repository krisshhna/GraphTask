import { Component } from '@angular/core';
import { AllListingService } from 'src/app/services/all-listing.service';

@Component({
  selector: 'app-laravel',
  templateUrl: './laravel.component.html',
  styleUrls: ['./laravel.component.scss']
})
export class LaravelComponent {
  status:any;
  doughnut:any;
  lineChart:any;

  constructor(public alist:AllListingService){}

  ngOnInit(){
    this.allGraphList();
  }

  allGraphList(){
    this.alist.allLaravelGraph().subscribe((res:any)=>{
      this.status = res.status;

      this.doughnut     = res.result.doughnut;
      this.lineChart    =  res.result.lineChart;
    })
  }
}
