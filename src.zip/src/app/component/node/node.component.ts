import { Component } from '@angular/core';
import { AllListingService } from 'src/app/services/all-listing.service';

@Component({
  selector: 'app-node',
  templateUrl: './node.component.html',
  styleUrls: ['./node.component.scss']
})
export class NodeComponent {
  status:any;
  doughnut:any;
  lineChart:any;

  constructor(public alist:AllListingService){}

  ngOnInit(){
    this.allGraphList();
  }

  allGraphList(){
    this.alist.allGraph().subscribe((res:any)=>{
      this.status = res.status;

      this.doughnut     = res.result.doughnut;
      this.lineChart    =  res.result.lineChart;
    })
  }
}
