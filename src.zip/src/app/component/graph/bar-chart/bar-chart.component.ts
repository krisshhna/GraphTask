import { Component, Input, EventEmitter } from '@angular/core';
import { ChartConfiguration } from 'chart.js';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent {
  @Input() graphPoint = new EventEmitter();
  barChart:any;

  public barChartLegend = true;
  public barChartPlugins = [];

  public barChartData: ChartConfiguration<'bar'>['data'] = {
    labels: [ ],
    datasets: [
    ]
  };

  public barChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: false,
  };

  ngOnInit(){
    this.barChart  = this.graphPoint;

    let data:any = [];
    let label:any=[];

    this.barChart.forEach((element:any)=>{
        data.push({data:element.data, label:'series A'});
        label = element.labels;
    })
    this.barChartData.labels = label;
    this.barChartData.datasets = data;
  }
}
