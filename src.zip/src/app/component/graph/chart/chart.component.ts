import { Component, Input, EventEmitter } from '@angular/core';
import { ChartConfiguration, ChartOptions, ChartType } from "chart.js";

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent {
  @Input() graphPoint = new EventEmitter();
  public lineChartData: ChartConfiguration<'line'>['data'] = {
    labels: [ ],
    datasets: [
      {
        data: [ ],
        label: '',
      },
    ]
  };
  public lineChartOptions: ChartOptions<'line'> = {
    responsive: false
  };
  public lineChartLegend = true;

  lineChart:any;

  ngOnInit(){
    this.lineChart  = this.graphPoint;

    let data:any = [];
    let label:any=[];
    this.lineChart.forEach((element:any)=>{
        data.push({data:element.data, label:'series A',fill:true, tension:0.8, borderColor:'black', backgroundColor:element.color});
        label = element.labels;
    })
    this.lineChartData.labels = label;
    this.lineChartData.datasets = data;
  }
}
