import { Component, EventEmitter, Input } from '@angular/core';
import { ChartConfiguration } from 'chart.js';

@Component({
  selector: 'app-doughnut-chart',
  templateUrl: './doughnut-chart.component.html',
  styleUrls: ['./doughnut-chart.component.scss']
})
export class DoughnutChartComponent {
  @Input() graphPoint =   new EventEmitter();
  plotPoint:any;

  public doughnutChartLabels: string[] = [ 'Series A', 'Series B', 'Series C', 'Seriec D' ];
  public doughnutChartDatasets: ChartConfiguration<'doughnut'>['data']['datasets'] = [
      { data: [], label: '' },
    ];

  public doughnutChartOptions: ChartConfiguration<'doughnut'>['options'] = {
    responsive: false
  };

  constructor(){}

  ngOnInit(){
      this.plotPoint  = this.graphPoint;
      console.log(this.plotPoint);
      this.doughnutChartDatasets = this.plotPoint;
  }
}
