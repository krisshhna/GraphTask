import { Component, Input, EventEmitter } from '@angular/core';
import { ChartOptions } from 'chart.js';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.scss']
})
export class PieChartComponent {
  @Input() graphPoint = new EventEmitter();
  pieChart:any;

  public pieChartOptions: ChartOptions<'pie'> = {
    responsive: false,
  };
  public pieChartLabels = [ 'Download', 'Sales', 'Mail Sales' ];
  public pieChartDatasets = [ {
    data: []
  } ];
  public pieChartLegend = true;
  public pieChartPlugins = [];

  ngOnInit(){
    this.pieChart  = this.graphPoint;

    let data:any = [];
    let label:any=[];
    this.pieChart.forEach((element:any)=>{
        data.push({data:element.data});
        label = element.labels;
    })
    this.pieChartDatasets = data;
  }
}
