import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NodeComponent } from './component/node/node.component';
import { LaravelComponent } from './component/laravel/laravel.component';
import { DoughnutChartComponent } from './component/graph/doughnut-chart/doughnut-chart.component';
import { LineChartComponent } from './component/graph/line-chart/line-chart.component';
import { PieChartComponent } from './component/graph/pie-chart/pie-chart.component';
import { ChartComponent } from './component/graph/chart/chart.component';
import { BarChartComponent } from './component/graph/bar-chart/bar-chart.component';

const routes: Routes = [
  {path:'node',     component:NodeComponent},
  {path:'laravel',  component:LaravelComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const allcomponent = [
  NodeComponent, LaravelComponent, DoughnutChartComponent, LineChartComponent, ChartComponent, PieChartComponent, BarChartComponent
]