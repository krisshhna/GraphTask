<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class lineChart extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('line_chart')->insert([
            'labels' =>  '["Jan","Feb", "Mar", "Apr", "May","Jun", "Jul"]',
            'data' =>  '[ 65, 59, 80, 81, 56, 55, 40 ]',
        ]);
    }
}
