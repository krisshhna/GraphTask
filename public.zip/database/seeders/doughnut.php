<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class doughnut extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('doughnut')->insert([
            'label' =>  'Series A',
            'data' =>  '[400,200,100,200]',
            'names' =>   '["First","second", "third", "fourth"]'
        ]);
    }
}
