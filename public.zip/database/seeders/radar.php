<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class radar extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('radar')->insert([
            'label' =>  'Series A',
            'data' =>  '[400,200,100,200,394,450,300]',
            'names' =>   '["Sun","Mon", "tue", "wed", "Thurs","Fri", "sat"]'
        ]);
    }
}
