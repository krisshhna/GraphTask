<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Models\Doughnut;
use App\Models\Radar;
use App\Models\Scatter;
use App\Models\LineChart;

class Listings extends Controller
{
    public function allRecords(){
        try{
            Log::info('inside allrecords');
            $allDoughnut    =   Doughnut::select('label','data')->get();
            $radar          =   Radar::select(['id', 'label', 'data', 'names'])->get();
            $scatter        =   Scatter::select(['id', 'xAxis', 'yAxis'])->get();
            $linechart      =   LineChart::select(['id', 'labels', 'data'])->get();
            foreach($linechart as $line){
                $line['labels'] =   substr($line['labels'],1,-1);
                $convlabel      =   explode(',',$line['labels']);
                $line['labels'] =   $convlabel;
                foreach($line['labels'] as $va){
                    $va     =   intval($va);
                }

                $line['data']   =   substr($line['data'],1,-1);
                $convdata       =   explode(',', $line['data']);
                $line['data']   =   $convdata;
                foreach($line['data'] as $da){
                    $da     =   intval($da);
                }
            }
            $result =   [
                'doughnut'      =>  $allDoughnut, 
                'lineChart'     =>  $linechart,
            ];

            return response(['status'=> 1,'result'=>$result]);
        }catch(Exception $e){
            Log::error('Listings::allRecords- error'.$e);
        }
    }
}
